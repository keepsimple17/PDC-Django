## Script Sql com todos os Estados, Municipios, Bairros e Regiões do Brasil

Os dados se encontram com o código oficial do IBGE.

27 Estados 
5.570 Municipios
14.320 Bairros
5 Regiões (Norte, Nordeste, Sudeste, Sul, Centro-Oeste)

É possível verificar os dados utilizados nos scripts no sistema [SIDRA](https://sidra.ibge.gov.br/territorio) e efetuar downloads das planilhas.

**Nota** Atualizado em 13/04/2017
